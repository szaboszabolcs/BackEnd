﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace Server
{
    internal class ClientCon
    {
        private StreamWriter writer = null;
        StreamReader reader = null;

        public ClientCon(TcpClient client)
        {
            reader = new StreamReader(client.GetStream(), Encoding.UTF8);
            writer = new StreamWriter(client.GetStream(), Encoding.UTF8);
        }

        public void CommStart()
        {
            writer.WriteLine("Szerver neve: BackEnd szerver 1.0");
            writer.Flush();
            bool end=false;
            while (!end)
            {
                string command = reader.ReadLine();
                string[] parameters = command.Split('|');
                switch (parameters[0])
                {
                    case "BYE":
                        {
                            writer.WriteLine("Csá...!");
                            end = true;
                            Disconnect();
                            break;
                        }
                    case "OSSZE":
                        {
                            writer.WriteLine(Osszeadas(double.Parse(parameters[1]), double.Parse(parameters[2])));
                            break;
                        }
                    case "DEREKSZOGU":
                        {
                            writer.WriteLine(Derekszogu(bool.Parse(parameters[1]), bool.Parse(parameters[2]), bool.Parse(parameters[3])));
                            Console.WriteLine("A háromszög derékszögű.");
                            break;
                        }
                    default:
                        {
                            writer.WriteLine("Error! Hibás utasítás!");
                            Console.WriteLine("Idióta van a gépnél!");
                            break;
                        }
                }
                writer.Flush();
            }

        }

        private double Osszeadas(double a, double b)
        {
            return a + b;
        }

        private bool Derekszogu(bool a, bool b, bool c)
        {
            return false;
            
        }

        private void Disconnect()
        {
            Console.WriteLine("A kliens lecsatlakozott....");
        }
       
    }
}
