﻿using System.Net;
using System.Net.Sockets;

namespace Server
{
    internal class Program
    {
        static string ipAddress = "127.0.0.1";
        static int port = 50000;
        static IPAddress ip = null;
        static TcpListener listener = null;

        static void comm()
        {
            TcpClient client = listener.AcceptTcpClient();
            ClientCon client1 = new ClientCon(client);
            Thread szal1 = new Thread(client1.CommStart);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Kliens csatlakozott");
            szal1.Start();
            
        }

        static void Main(string[] args)
        {
            ip=IPAddress.Parse(ipAddress);
            listener = new TcpListener(ip,port);
            listener.Start();
            Console.WriteLine($"A szerver ipcíme: {ipAddress}, portszáma" +
                $": {port}");
            comm();
        }
    }
}