﻿using System.Net.Sockets;
using System.Text;

TcpClient client = new TcpClient("localhost", 50000);
StreamReader reader = new StreamReader(client.GetStream(), Encoding.UTF8);
StreamWriter writer = new StreamWriter(client.GetStream(), Encoding.UTF8);
bool end = false;
string message = reader.ReadLine();
Console.WriteLine(message);
while (!end)
{
    string command = Console.ReadLine();
    writer.WriteLine(command);
    writer.Flush();
    message = reader.ReadLine();
    Console.WriteLine(message);
    if (message == "Csá...!")
    {
        end = true;
    }
}