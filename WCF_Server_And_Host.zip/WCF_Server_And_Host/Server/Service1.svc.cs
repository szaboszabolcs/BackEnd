﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Server
{
    public class Service1 : IService1
    {
        public List<Kutya> kutyaLista = new List<Kutya>();
        public Kutya EgyKutyaGet()
        {
            Kutya kutya = new Kutya();
            kutya.ID = 1;
            kutya.Nev = "Buksi";
            kutya.Eletkor = 5;
            kutya.Fajta = "Husky";
            kutya.Neme = null; //még nem döntötte el
            kutya.Gazdi = "Kin Csung Csin Leng";
            kutya.LabakSzama = 4;
            return kutya;
        }

        public void EgyKutyaPost()
        {
            Kutya kutya = new Kutya();
            kutya.ID = 1;
            kutya.Nev = "Buksi IV.";
            kutya.Eletkor = 10;
            kutya.Fajta = "Csivava";
            kutya.Neme = false; //még nem döntötte el
            kutya.Gazdi = "Kin Ben Csin Leng Fing";
            kutya.LabakSzama = 2;
            kutyaLista.Add(kutya);
        }

        public List<Kutya> KutyakListaja()
        {
            return kutyaLista;
        }
    }
}
