﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using WCF_Client.ServiceReference1;

namespace WCF_Client
{
    internal class Program
    {
        public static ServiceReference1.Service1Client kliens=new ServiceReference1.Service1Client();
        static void Main(string[] args)
        {
            Kutya egyKutya = new Kutya();
            egyKutya = kliens.EgyKutyaGet();
            Console.WriteLine(egyKutya);
            Console.ReadKey();
            
            
        }
    }
}
